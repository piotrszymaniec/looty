

console.log("Embed Startup start")
EmbedMain().main()
console.log("Embed Startup end")